package com.example.resumegenerator.model;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface RecruiterRepository extends JpaRepository<Recruiter, Long> {
	List<Recruiter> findByFirstName(String firstName);
	List<Recruiter> findByLastName(String lastName);
	Optional<Recruiter> findByRecruiterEmail(String recruiterEmail);
	
}