package com.example.resumegenerator.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Experience {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long id;
	private String company;
	private String title;
	private String date;
	private String tasks;
	
	public Experience() {}
	
	public Experience(String company, String title, String date, String tasks) {
		this.company = company;
		this.title = title;
		this.date = date;
		this.tasks = tasks;
	}
	
	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getTasks() {
		return tasks;
	}
	public void setTasks(String tasks) {
		this.tasks = tasks;
	}
	
	

}
