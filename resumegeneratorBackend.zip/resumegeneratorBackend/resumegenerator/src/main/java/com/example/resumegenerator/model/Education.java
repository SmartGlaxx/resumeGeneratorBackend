package com.example.resumegenerator.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Education {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long id;
	private String school;
	private String date;
	private String course;
	
	public Education() {}
	
	public Education(String school, String date, String course) {
		this.school = school;
		this.date = date;
		this.course = course;
	}
	
	public String getSchool() {
		return school;
	}

	public void setSchool(String school) {
		this.school = school;
	}

	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}
	
	

}
