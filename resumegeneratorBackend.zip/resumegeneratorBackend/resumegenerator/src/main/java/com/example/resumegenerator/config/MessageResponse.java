package com.example.resumegenerator.config;

public class MessageResponse {

}
