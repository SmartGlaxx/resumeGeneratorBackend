package com.example.resumegenerator;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.example.resumegenerator.model.Experience;
import com.example.resumegenerator.model.Recruiter;
import com.example.resumegenerator.model.RecruiterRepository;
import com.example.resumegenerator.model.Education;
import com.example.resumegenerator.model.Resume;
import com.example.resumegenerator.model.ResumeRepository;
import com.example.resumegenerator.model.User;
import com.example.resumegenerator.model.UserRepository;

@SpringBootApplication
public class ResumegeneratorApplication {

	
	public static void main(String[] args) {
		SpringApplication.run(ResumegeneratorApplication.class, args);
	}

	@Bean
	ApplicationRunner initUser(UserRepository userRepo) {
		return arg -> {
			userRepo.save(new User("Smart", "Egbuchulem" , "smart@gmail.com", "123"));
			userRepo.findAll().forEach(System.out::print);
		};
	}
	
	@Bean
	ApplicationRunner initRecruiter(RecruiterRepository recruiterRepo) {
		return arg -> {
			recruiterRepo.save(new Recruiter("SmartRecruiter", "EgbuchulemRecruiter" , "smartRecruiter@gmail.com", "123"));
			recruiterRepo.findAll().forEach(System.out::print);
		};
	}
	
	@Bean
	ApplicationRunner initResume(ResumeRepository resumeRepo) {
		Experience experience1 = new Experience("Shell", "worker","2020", "work on oil rig");
		Experience experience2 = new Experience("Total", "worker","2018", "work on oil rig");
		List <Experience> experienceList = new ArrayList<Experience>();
		experienceList.add(experience1);
		experienceList.add(experience2);
		
		Education education1 = new Education("FUTO", "2020", "Elect");
		Education education2 = new Education("Douglas","2018", "IT");
		List <Education> educationList = new ArrayList<Education>();
		educationList.add(education1);
		educationList.add(education2);
		List<String> skills = new ArrayList<String>(Arrays.asList("Microsoft suite","Organization skills","Team player"));

		return arg -> {
			resumeRepo.save(new Resume("1", 
					"Smart", "Egbuchulem",
					"smart@gmail.com", "12383 106 Avenue, Surrey", "7787512212", 
					"I am a self-motivated and detail-oriented individual with a passion for technology.", 
					experienceList,
					educationList, 
					skills));
			resumeRepo.findAll().forEach(System.out::print);
		};
	}
	
}
