package com.example.resumegenerator.controller;


import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.resumegenerator.response.MessageResponse;
import com.example.resumegenerator.model.Recruiter;
import com.example.resumegenerator.model.RecruiterRepository;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@CrossOrigin(maxAge = 3600)
@RestController
public class RecruiterController {

	@Autowired
	RecruiterRepository recruiterRepo;
	
	@CrossOrigin(origins = "http://localhost:8081", allowedHeaders = "Requestor-Type", exposedHeaders = "X-Get-Header")
	@GetMapping("/recruiters/list")
	public ResponseEntity <List<Recruiter>> getAllRecruiters(){
		try {
			List<Recruiter> recruiters = new ArrayList<>();
			
			if(recruiters.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			return new ResponseEntity<>(recruiters, HttpStatus.OK);
		}catch(Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("/recruiters/{id}")
	public ResponseEntity<Recruiter> getRecruiter(@PathVariable long id){
		try {
			Optional <Recruiter> recruiter = recruiterRepo.findById(id);
			return new ResponseEntity<>(recruiter.get(), HttpStatus.OK);
		}catch(Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping("/recruiters/signup")
	public ResponseEntity<Recruiter> signUpUser(@RequestBody Recruiter recruiter){
		try {
			Recruiter newRecruiter = recruiterRepo.save(new Recruiter(recruiter.getFirstName(), recruiter.getLastName(), recruiter.getRecruiterEmail(), recruiter.getPassword()));
			return new ResponseEntity<>(newRecruiter, HttpStatus.CREATED);
		}catch(Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PutMapping("/recruiters/update/{email}")
	public ResponseEntity<Recruiter> updateRecruiter(@RequestBody Recruiter newRecruiter, @PathVariable String email){
		try {
			Optional <Recruiter> recruiter = recruiterRepo.findByRecruiterEmail(email);
			if(recruiter == null) {
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
			Recruiter newRecruiterData = recruiter.get();
			newRecruiterData.setFirstName(newRecruiter.getFirstName());
			newRecruiterData.setLastName(newRecruiter.getLastName());
			newRecruiterData.setRecruiterEmail(newRecruiter.getRecruiterEmail());
			newRecruiterData.setPassword(newRecruiter.getPassword());
			recruiterRepo.save(newRecruiterData);
			return new ResponseEntity<>(newRecruiterData, HttpStatus.OK);
		}catch(Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@DeleteMapping("/recruiters/delete/{email}")
	public ResponseEntity<Recruiter> deleteRecruiter(@PathVariable String email){
		try {
			Optional <Recruiter> recruiter = recruiterRepo.findByRecruiterEmail(email);
			if(recruiter == null) {
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
			recruiterRepo.findByRecruiterEmail(email);
			return new ResponseEntity<>(HttpStatus.OK);
		}catch(Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	

    @PostMapping("/recruiters/signin")
    public ResponseEntity<?> login(@RequestBody Recruiter recruiter, HttpSession session) {    	
    	try {
			Optional<Recruiter> recruiterData = recruiterRepo.findByRecruiterEmail(recruiter.getRecruiterEmail());
			if (recruiterData.isPresent()) {
				String password = recruiterData.get().getPassword();
				if (password.equals(recruiter.getPassword())) {
					session.setAttribute("recruitermail", recruiter.getRecruiterEmail());
					return new ResponseEntity<>(recruiterData.get(), HttpStatus.OK);
				}
				MessageResponse message = new MessageResponse("Incorrect password");
				return new ResponseEntity<>(message, HttpStatus.FORBIDDEN);
			}
			MessageResponse message = new MessageResponse("Recruiter not found");
			return new ResponseEntity<>(message, HttpStatus.FORBIDDEN);
		} catch (Exception e) {
			MessageResponse message = new MessageResponse("Server Error");
			return new ResponseEntity<>(message, HttpStatus.INTERNAL_SERVER_ERROR);
		}
       
    }

    
    @PostMapping("/recruiters/logoutRecruiter")
    public ResponseEntity<Recruiter> logoutRecruiter(HttpServletRequest request) {
        HttpSession session = request.getSession(false); 
        if (session != null) {
            session.invalidate();
        }
        return new ResponseEntity<>(HttpStatus.OK);
    }
    
    @GetMapping("/checkRecruiterLogin")
    public ResponseEntity<Boolean> checkLogin(HttpSession session) {
        String recruiterEmail = (String) session.getAttribute("recruiterEmail");
        if (recruiterEmail != null) {
            return new ResponseEntity<>(true, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(false, HttpStatus.OK);
        }
    }

	
}