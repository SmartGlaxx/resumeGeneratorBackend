package com.example.resumegenerator.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.resumegenerator.model.Experience;
import com.example.resumegenerator.model.Resume;
import com.example.resumegenerator.model.ResumeRepository;
import com.example.resumegenerator.model.User;

import jakarta.persistence.Column;

@CrossOrigin(maxAge = 3600)
@RequestMapping("/resumes")
@RestController
public class ResumeController {

	@Autowired
	ResumeRepository resumeRepo;
	
	@CrossOrigin(origins = "http://localhost:8081", allowedHeaders = "Requestor-Type", exposedHeaders = "X-Get-Header")
	@GetMapping("/list")
	public ResponseEntity<List<Resume>> getResumesByTask(@RequestParam(required = false) String task) {
		try {
			List<Resume> resumes = new ArrayList<>();
			if (task == null) {
				resumeRepo.findAll().forEach(resumes::add);
			} else {
				List<Resume> matchingResumes = new ArrayList<>();
				List<Resume> allResumes = resumeRepo.findAll();
				for (Resume resume : allResumes) {
					for (Experience experience : resume.getExperience()) {
						for (String taskString : experience.getTasks()) {
							if (taskString.contains(task)) {
								matchingResumes.add(resume);
								break;
							}
						}
					}
				}
				resumes.addAll(matchingResumes);
			}
			if (resumes.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			return new ResponseEntity<>(resumes, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping("/create")
	public ResponseEntity<Resume> createResume(@RequestBody Resume resume){
		try {
			Resume newResume = resumeRepo.save(new Resume(resume.getUserId(), resume.getFirstName(), 
					resume.getLastName(), resume.getEmail(), resume.getAddress(),
					resume.getPhone(), resume.getIntro(), resume.getExperience(),
					resume.getEducation(), resume.getSkills()));
			return new ResponseEntity<>(newResume, HttpStatus.CREATED);
		}catch(Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("/list/{email}")
	public ResponseEntity<List<Resume>> getAllUserResumes(@PathVariable String email){
		try {
			List<Resume> resumes = new ArrayList<Resume>();
			resumeRepo.findByEmail(email).forEach(resumes::add);
			return new ResponseEntity<>(resumes, HttpStatus.OK);
		}catch(Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	@GetMapping("/list/{email}/{resumeId}")
	public ResponseEntity<Resume> getAUserResume(@PathVariable String email, @PathVariable long resumeId){
		try {
			Optional<Resume> resume = resumeRepo.findById(resumeId);
			if(resume.get().getEmail().equalsIgnoreCase(email)) {
				return new ResponseEntity<>(resume.get(), HttpStatus.OK);	
			}
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}catch(Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PutMapping("/update/{userEmail}/{resumeId}")
	public ResponseEntity<Resume> updateResume(@RequestBody Resume newResume, @PathVariable String userEmail, @PathVariable long resumeId){
		try {
			Optional <Resume> resume = resumeRepo.findById(resumeId);
			if(resume.get().getEmail().equalsIgnoreCase(userEmail)) {
				Resume newResumeData = resume.get();
				newResumeData.setUserId(newResume.getUserId());
				newResumeData.setFirstName(newResume.getFirstName());
				newResumeData.setLastName(newResume.getLastName());
				newResumeData.setEmail(newResume.getEmail());
				newResumeData.setAddress(newResume.getAddress());
				newResumeData.setPhone(newResume.getPhone());
				newResumeData.setIntro(newResume.getIntro());
				newResumeData.setExperience(newResume.getExperience());
				newResumeData.setEducation(newResume.getEducation());
				newResumeData.setSkills(newResume.getSkills());
				resumeRepo.save(newResumeData);
				return new ResponseEntity<>(newResumeData, HttpStatus.OK);
			}
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}catch(Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@DeleteMapping("/delete/{userEmail}/{resumeId}")
	public ResponseEntity<Resume> deleteUser(@PathVariable String userEmail, @PathVariable long resumeId){
		try {
			Optional <Resume> resume = resumeRepo.findById(resumeId);
			if(resume == null) {
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
			if(resume.get().getEmail().equalsIgnoreCase(userEmail)) {
				resumeRepo.deleteById(resumeId);				
				return new ResponseEntity<>(HttpStatus.OK);
			}
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}catch(Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	

	
	
}
