package com.example.resumegenerator.model;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface EducationRepository extends JpaRepository<Education, Long>{
	List<Education> findByCourse(String course);
}
